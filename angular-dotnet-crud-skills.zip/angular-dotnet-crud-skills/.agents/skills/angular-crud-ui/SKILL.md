---
name: angular-crud-ui
description: Build or extend an Angular CRUD user interface that consumes an existing REST API, following the app's current standalone or NgModule architecture, routing, forms, UI library, authentication, and testing conventions. Use for frontend-only Angular CRUD work. Do not use to implement the ASP.NET Core API or database schema.
---

# Angular CRUD UI

Implement one complete Angular CRUD feature against an existing, verified REST API contract.

## Boundaries

- Work only in the Angular application unless a tiny workspace-level change is required.
- Do not modify backend behavior, EF Core entities, migrations, or controllers.
- Do not invent API fields or response envelopes when backend code, OpenAPI, or a supplied contract is available.
- Do not switch between standalone and NgModule architecture.
- Do not add a new state library or UI framework unless explicitly requested.

## 1. Inspect before editing

1. Read applicable `AGENTS.md` and `AGENTS.override.md` files.
2. Inspect `package.json`, `angular.json`, TypeScript config, environment/config files, routes, providers, interceptors, shared UI, styles, and tests.
3. Determine:
   - Angular version;
   - standalone components versus NgModules;
   - reactive forms versus template-driven forms;
   - existing UI library and design patterns;
   - API base URL strategy;
   - authentication/token interceptor behavior;
   - RxJS, Signals, store, notification, dialog, and error-handling conventions.
4. Inspect one or two similar CRUD features and follow their folder structure and naming.
5. Preserve unrelated working-tree changes.

## 2. Verify the API contract

Use, in priority order:

1. supplied API contract;
2. OpenAPI/Swagger document or generated client;
3. ASP.NET Core DTOs and controller routes;
4. existing Angular API types and services.

Confirm:

- base URL and routes;
- request and response field names and nullability;
- ID type;
- date/time and enum representation;
- list envelope and pagination metadata;
- search, filter, sort, and pagination parameters;
- validation/error response shape;
- authentication and authorization requirements.

If the API contract is inconsistent, do not silently guess. Implement the safest compatible part and report the mismatch precisely.

## 3. Implement the smallest complete feature

Use existing project conventions to add only what is needed:

- TypeScript request/response interfaces or models;
- API service using `HttpClient` or the existing generated client;
- list page/component;
- create and edit form, shared when appropriate;
- detail view only when requested or conventional;
- route definitions and lazy loading;
- delete confirmation;
- loading, empty, success, and error states;
- pagination, search, filtering, and sorting requested by the contract;
- component/service tests.

Avoid duplicate models when generated OpenAPI types already exist.

## 4. Forms and validation

- Use the project's existing form style; prefer Reactive Forms when no pattern exists.
- Mirror backend required, length, range, format, and cross-field rules for user feedback.
- Treat backend validation as authoritative and map server field errors into the form when possible.
- Keep create and edit defaults distinct.
- Convert dates, numbers, booleans, enums, and nullable values deliberately.
- Prevent duplicate submissions while a request is pending.
- Never send server-owned fields unless the API requires them.

## 5. API and UI behavior

- Keep API calls in services, not presentation templates.
- Reuse existing interceptors for tokens, errors, and base URLs.
- Use URL query parameters for list state when that is the app's convention.
- Debounce search only when appropriate and cancel stale requests with the project's RxJS pattern.
- Avoid nested subscriptions and memory leaks.
- Refresh or update local state consistently after create, update, and delete.
- Show clear authorization, not-found, validation, conflict, and network errors.
- Preserve accessibility: labels, keyboard operation, focus behavior, semantic controls, and meaningful error text.
- Follow current responsive layout and styling; do not redesign unrelated screens.

## 6. Configuration and security

- Use the existing environment/runtime config for the API base URL.
- Do not hard-code secrets or production URLs.
- Do not store sensitive tokens in new locations.
- Do not bypass route guards or authorization checks.
- Do not “fix” CORS from Angular; report the exact backend origin/configuration needed.
- Escape or render untrusted content safely; avoid unsafe HTML APIs.

## 7. Tests and verification

Test applicable behavior:

- service URL, method, request body, and query parameters;
- list loading, empty, data, and error states;
- create/edit validation and submission;
- backend validation mapping;
- delete confirmation and refresh;
- routing and protected behavior when relevant.

Discover commands from `package.json`. Run the relevant checks, commonly:

```text
npm run lint
npm test -- --watch=false
npm run build
```

Use the repository's actual package manager and scripts. Never claim a check passed unless it ran successfully.

## Definition of done

The feature is routed and usable, matches the real API contract, validates inputs, handles loading/errors, respects authentication, passes relevant Angular checks or reports blockers, and does not alter unrelated code.

## Final report

Return:

1. **Implemented screens and behavior**
2. **Files changed**
3. **API contract consumed**
4. **Forms and validation**
5. **Routing and authentication**
6. **Commands run and results**
7. **Backend mismatches or blockers**
